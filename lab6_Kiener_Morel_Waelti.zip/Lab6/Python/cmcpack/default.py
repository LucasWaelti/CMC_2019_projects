""" Default parameters """

DEFAULT = {
    "label": ["State 0", "State 1"],
    "save_figures": False,
    "save_extensions": ["pdf"]
}

